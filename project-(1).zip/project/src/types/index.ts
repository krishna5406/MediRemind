export interface User {
  id: string;
  email: string;
  name?: string;
}

export type MedicineType = 
  | 'capsule'
  | 'tablet'
  | 'liquid'
  | 'injection'
  | 'drops'
  | 'inhaler'
  | 'topical'
  | 'patch'
  | 'other';

export interface Medicine {
  id: string;
  userId: string;
  name: string;
  type: MedicineType;
  dosage: string;
  instructions?: string;
  startDate: string;
  endDate?: string;
  schedules: DosageSchedule[];
  color?: string;
  createdAt: string;
  updatedAt: string;
  isActive: boolean;
}

export interface DosageSchedule {
  id: string;
  time: string; // 24-hour format HH:MM
  taken?: boolean;
  takenAt?: string;
}

export interface ReminderHistory {
  id: string;
  medicineId: string;
  medicineName: string;
  scheduleTime: string;
  scheduledDate: string;
  status: 'taken' | 'missed' | 'skipped';
  takenAt?: string;
}