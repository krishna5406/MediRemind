import { Medicine, MedicineType, DosageSchedule } from '../types';

// Simulated database
let medicines: Medicine[] = [];

// Load from localStorage on initialization
try {
  const storedMedicines = localStorage.getItem('medicines');
  if (storedMedicines) {
    medicines = JSON.parse(storedMedicines);
  }
} catch (e) {
  console.error('Failed to load medicines from localStorage', e);
}

// Helper to persist to localStorage
const persistMedicines = () => {
  localStorage.setItem('medicines', JSON.stringify(medicines));
};

export const getMedicines = (userId: string): Promise<Medicine[]> => {
  return new Promise((resolve) => {
    setTimeout(() => {
      resolve(medicines.filter(med => med.userId === userId));
    }, 300);
  });
};

export const getMedicineById = (id: string): Promise<Medicine | null> => {
  return new Promise((resolve) => {
    setTimeout(() => {
      const medicine = medicines.find(med => med.id === id) || null;
      resolve(medicine);
    }, 300);
  });
};

export const createMedicine = (
  userId: string,
  name: string, 
  type: MedicineType, 
  dosage: string,
  startDate: string,
  endDate: string | undefined,
  schedules: Omit<DosageSchedule, 'id'>[],
  instructions?: string,
  color?: string
): Promise<Medicine> => {
  return new Promise((resolve) => {
    setTimeout(() => {
      const now = new Date().toISOString();
      const newMedicine: Medicine = {
        id: `med-${Date.now()}`,
        userId,
        name,
        type,
        dosage,
        instructions,
        startDate,
        endDate,
        schedules: schedules.map(schedule => ({
          ...schedule,
          id: `schedule-${Date.now()}-${Math.random().toString(36).substring(2, 9)}`
        })),
        color,
        createdAt: now,
        updatedAt: now,
        isActive: true
      };
      
      medicines.push(newMedicine);
      persistMedicines();
      resolve(newMedicine);
    }, 500);
  });
};

export const updateMedicine = (
  id: string,
  updates: Partial<Omit<Medicine, 'id' | 'userId' | 'createdAt'>>
): Promise<Medicine> => {
  return new Promise((resolve, reject) => {
    setTimeout(() => {
      const index = medicines.findIndex(med => med.id === id);
      if (index === -1) {
        reject(new Error('Medicine not found'));
        return;
      }
      
      const updatedMedicine = {
        ...medicines[index],
        ...updates,
        updatedAt: new Date().toISOString()
      };
      
      medicines[index] = updatedMedicine;
      persistMedicines();
      resolve(updatedMedicine);
    }, 500);
  });
};

export const deleteMedicine = (id: string): Promise<void> => {
  return new Promise((resolve, reject) => {
    setTimeout(() => {
      const initialLength = medicines.length;
      medicines = medicines.filter(med => med.id !== id);
      
      if (medicines.length === initialLength) {
        reject(new Error('Medicine not found'));
        return;
      }
      
      persistMedicines();
      resolve();
    }, 500);
  });
};

export const recordDosageTaken = (
  medicineId: string, 
  scheduleId: string
): Promise<Medicine> => {
  return new Promise((resolve, reject) => {
    setTimeout(() => {
      const medicineIndex = medicines.findIndex(med => med.id === medicineId);
      if (medicineIndex === -1) {
        reject(new Error('Medicine not found'));
        return;
      }
      
      const medicine = medicines[medicineIndex];
      const scheduleIndex = medicine.schedules.findIndex(s => s.id === scheduleId);
      
      if (scheduleIndex === -1) {
        reject(new Error('Schedule not found'));
        return;
      }
      
      const updatedSchedules = [...medicine.schedules];
      updatedSchedules[scheduleIndex] = {
        ...updatedSchedules[scheduleIndex],
        taken: true,
        takenAt: new Date().toISOString()
      };
      
      const updatedMedicine = {
        ...medicine,
        schedules: updatedSchedules,
        updatedAt: new Date().toISOString()
      };
      
      medicines[medicineIndex] = updatedMedicine;
      persistMedicines();
      resolve(updatedMedicine);
    }, 300);
  });
};