import { Medicine } from '../types';
import useSound from 'use-sound';

// Professional notification sound
const NOTIFICATION_SOUND = 'https://assets.mixkit.co/sfx/preview/mixkit-happy-bells-notification-937.mp3';

// Check if browser supports notifications
const notificationsSupported = 'Notification' in window;

// Request permission to show notifications
export const requestNotificationPermission = async (): Promise<boolean> => {
  if (!notificationsSupported) {
    console.warn('Notifications not supported in this browser');
    return false;
  }

  const permission = await Notification.requestPermission();
  return permission === 'granted';
};

// Create and cache audio element for better performance
let audioElement: HTMLAudioElement | null = null;

// Initialize audio element
const initAudio = () => {
  if (!audioElement) {
    audioElement = new Audio(NOTIFICATION_SOUND);
    audioElement.preload = 'auto';
    audioElement.volume = 0.7; // Set volume to 70%
    audioElement.loop = true;
  }
  return audioElement;
};

// Play notification sound
const playSound = async () => {
  try {
    const audio = initAudio();
    
    // Reset audio to start if it was already playing
    audio.currentTime = 0;
    
    // Play the sound with a fade-in effect
    audio.volume = 0;
    const fadeIn = setInterval(() => {
      if (audio.volume < 0.7) {
        audio.volume += 0.1;
      } else {
        clearInterval(fadeIn);
      }
    }, 200);
    
    const playPromise = audio.play();
    
    if (playPromise !== undefined) {
      playPromise.catch((error) => {
        console.error('Failed to play notification sound:', error);
      });
    }
    
    // Stop the sound after 15 seconds if user hasn't interacted
    setTimeout(() => {
      if (audio) {
        // Fade out
        const fadeOut = setInterval(() => {
          if (audio.volume > 0.1) {
            audio.volume -= 0.1;
          } else {
            clearInterval(fadeOut);
            audio.pause();
            audio.currentTime = 0;
          }
        }, 200);
      }
    }, 15000);
  } catch (error) {
    console.error('Error playing sound:', error);
  }
};

// Show a notification for a medicine reminder
export const showMedicineReminder = (medicine: Medicine): void => {
  if (!notificationsSupported || Notification.permission !== 'granted') {
    alert(`🔔 Medicine Reminder: Time to take ${medicine.name}`);
    playSound();
    return;
  }

  const options = {
    body: `It's time for your ${medicine.dosage} of ${medicine.name}.\n\n💊 Type: ${medicine.type}\n📝 Instructions: ${medicine.instructions || 'None provided'}`,
    icon: '/medicine-icon.png',
    badge: '/badge-icon.png',
    tag: `medicine-${medicine.id}`,
    renotify: true,
    requireInteraction: true,
    vibrate: [200, 100, 200], // Vibration pattern for mobile devices
    actions: [
      {
        action: 'take',
        title: '✅ Take Now'
      },
      {
        action: 'snooze',
        title: '⏰ Remind in 5min'
      }
    ]
  };

  const notification = new Notification('🔔 Medicine Reminder', options);
  playSound();

  notification.onclick = () => {
    window.focus();
    if (audioElement) {
      const fadeOut = setInterval(() => {
        if (audioElement && audioElement.volume > 0.1) {
          audioElement.volume -= 0.1;
        } else {
          clearInterval(fadeOut);
          if (audioElement) {
            audioElement.pause();
            audioElement.currentTime = 0;
          }
        }
      }, 100);
    }
    notification.close();
    window.location.href = `/medicine/${medicine.id}`;
  };

  // Handle notification actions
  notification.onaction = (event) => {
    if (event.action === 'take') {
      // Mark medicine as taken
      window.location.href = `/medicine/${medicine.id}?action=take`;
    } else if (event.action === 'snooze') {
      // Schedule a new reminder in 5 minutes
      setTimeout(() => showMedicineReminder(medicine), 5 * 60 * 1000);
    }
  };
};

// Schedule all medicine reminders
export const scheduleReminders = (medicines: Medicine[]): void => {
  clearAllReminders();

  const now = new Date();
  const activeReminders: Record<string, NodeJS.Timeout> = {};

  medicines.forEach(medicine => {
    if (!medicine.isActive) return;
    
    const startDate = new Date(medicine.startDate);
    const endDate = medicine.endDate ? new Date(medicine.endDate) : null;
    
    if (startDate > now || (endDate && endDate < now)) return;
    
    medicine.schedules.forEach(schedule => {
      const [hours, minutes] = schedule.time.split(':').map(Number);
      
      const scheduledTime = new Date();
      scheduledTime.setHours(hours, minutes, 0, 0);
      
      if (scheduledTime < now) {
        scheduledTime.setDate(scheduledTime.getDate() + 1);
      }
      
      const timeToWait = scheduledTime.getTime() - now.getTime();
      
      const timerId = setTimeout(() => {
        showMedicineReminder(medicine);
      }, timeToWait);
      
      activeReminders[`${medicine.id}-${schedule.id}`] = timerId;
    });
  });

  (window as any).__medicineReminders = activeReminders;
};

// Clear all scheduled reminders
export const clearAllReminders = (): void => {
  const activeReminders = (window as any).__medicineReminders || {};
  
  Object.values(activeReminders).forEach((timerId: NodeJS.Timeout) => {
    clearTimeout(timerId);
  });
  
  if (audioElement) {
    audioElement.pause();
    audioElement.currentTime = 0;
  }
  
  (window as any).__medicineReminders = {};
};