import { User } from '../types';

// Simulated authentication service - would be replaced with Firebase or similar
let currentUser: User | null = null;
const users: Record<string, { email: string; password: string; id: string }> = {};

export function createUserWithEmailAndPassword(email: string, password: string): Promise<void> {
  return new Promise((resolve, reject) => {
    setTimeout(() => {
      if (users[email]) {
        reject(new Error('User already exists'));
        return;
      }
      
      const id = `user-${Date.now()}`;
      users[email] = { email, password, id };
      currentUser = { id, email };
      localStorage.setItem('currentUser', JSON.stringify(currentUser));
      resolve();
    }, 500);
  });
}

export function signInWithEmailAndPassword(email: string, password: string): Promise<void> {
  return new Promise((resolve, reject) => {
    setTimeout(() => {
      const user = users[email];
      if (!user || user.password !== password) {
        reject(new Error('Invalid email or password'));
        return;
      }
      
      currentUser = { id: user.id, email: user.email };
      localStorage.setItem('currentUser', JSON.stringify(currentUser));
      resolve();
    }, 500);
  });
}

export function signOut(): Promise<void> {
  return new Promise((resolve) => {
    setTimeout(() => {
      currentUser = null;
      localStorage.removeItem('currentUser');
      resolve();
    }, 300);
  });
}

export function onAuthStateChanged(callback: (user: User | null) => void): () => void {
  // On first call, check localStorage
  const storedUser = localStorage.getItem('currentUser');
  if (storedUser) {
    try {
      currentUser = JSON.parse(storedUser);
    } catch (e) {
      currentUser = null;
    }
  }
  
  callback(currentUser);
  
  // Set up a listener for changes
  const interval = setInterval(() => {
    callback(currentUser);
  }, 2000);
  
  return () => clearInterval(interval);
}