import React from 'react';
import { BrowserRouter as Router, Routes, Route, Navigate } from 'react-router-dom';
import { AuthProvider, useAuth } from './context/AuthContext';
import { ThemeProvider } from './context/ThemeContext';
import AuthPage from './components/auth/AuthPage';
import Dashboard from './components/dashboard/Dashboard';
import AddMedicine from './components/medicines/AddMedicine';
import EditMedicine from './components/medicines/EditMedicine';
import MedicineHistory from './components/history/MedicineHistory';
import Layout from './components/layout/Layout';

const ProtectedRoute: React.FC<{ children: React.ReactNode }> = ({ children }) => {
  const { currentUser, loading } = useAuth();
  
  if (loading) {
    return <div className="flex justify-center items-center h-screen dark:bg-gray-900">
      <div className="h-8 w-8 border-4 border-t-blue-500 border-blue-200 rounded-full animate-spin"></div>
    </div>;
  }
  
  if (!currentUser) {
    return <Navigate to="/" />;
  }
  
  return <>{children}</>;
};

const PublicRoute: React.FC<{ children: React.ReactNode }> = ({ children }) => {
  const { currentUser, loading } = useAuth();
  
  if (loading) {
    return <div className="flex justify-center items-center h-screen dark:bg-gray-900">
      <div className="h-8 w-8 border-4 border-t-blue-500 border-blue-200 rounded-full animate-spin"></div>
    </div>;
  }
  
  if (currentUser) {
    return <Navigate to="/dashboard" />;
  }
  
  return <>{children}</>;
};

function App() {
  return (
    <ThemeProvider>
      <AuthProvider>
        <Router>
          <Routes>
            <Route path="/" element={
              <PublicRoute>
                <AuthPage />
              </PublicRoute>
            } />
            
            <Route element={
              <ProtectedRoute>
                <Layout />
              </ProtectedRoute>
            }>
              <Route path="/dashboard" element={<Dashboard />} />
              <Route path="/medicines/add" element={<AddMedicine />} />
              <Route path="/medicines/edit/:id" element={<EditMedicine />} />
              <Route path="/history" element={<MedicineHistory />} />
              <Route path="/calendar" element={<div className="p-8 dark:text-white">Calendar View (Coming Soon)</div>} />
              <Route path="/settings" element={<div className="p-8 dark:text-white">Settings (Coming Soon)</div>} />
            </Route>
            
            <Route path="*" element={<Navigate to="/" />} />
          </Routes>
        </Router>
      </AuthProvider>
    </ThemeProvider>
  );
}

export default App;