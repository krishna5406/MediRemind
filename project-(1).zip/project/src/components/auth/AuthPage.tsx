import React, { useState } from 'react';
import LoginForm from './LoginForm';
import RegisterForm from './RegisterForm';
import { Bell } from 'lucide-react';

const AuthPage: React.FC = () => {
  const [isLogin, setIsLogin] = useState(true);
  
  return (
    <div className="min-h-screen flex flex-col md:flex-row">
      <div className="w-full md:w-1/2 bg-gradient-to-br from-blue-500 to-blue-600 text-white flex flex-col justify-center p-12">
        <div className="max-w-md mx-auto">
          <div className="mb-8">
            <Bell className="h-12 w-12 text-white mb-4" />
            <h1 className="text-4xl font-bold mb-4">MediTrack</h1>
            <p className="text-xl opacity-80">Never miss a medication again with timely reminders and easy tracking.</p>
          </div>
          
          <div className="space-y-6">
            <div className="flex items-center">
              <div className="p-2 bg-blue-400 bg-opacity-30 rounded-full mr-4">
                <Bell className="h-6 w-6" />
              </div>
              <div>
                <h3 className="font-medium">Timely Reminders</h3>
                <p className="opacity-80">Get notifications when it's time to take your medicine</p>
              </div>
            </div>
            
            <div className="flex items-center">
              <div className="p-2 bg-blue-400 bg-opacity-30 rounded-full mr-4">
                <Bell className="h-6 w-6" />
              </div>
              <div>
                <h3 className="font-medium">Track Progress</h3>
                <p className="opacity-80">Monitor your medication history and adherence</p>
              </div>
            </div>
            
            <div className="flex items-center">
              <div className="p-2 bg-blue-400 bg-opacity-30 rounded-full mr-4">
                <Bell className="h-6 w-6" />
              </div>
              <div>
                <h3 className="font-medium">Medication Management</h3>
                <p className="opacity-80">Easily manage all your prescriptions in one place</p>
              </div>
            </div>
          </div>
        </div>
      </div>
      
      <div className="w-full md:w-1/2 flex items-center justify-center p-12 bg-white">
        <div className="w-full max-w-md">
          {isLogin ? <LoginForm /> : <RegisterForm />}
          
          <div className="mt-6 text-center">
            <p className="text-gray-600">
              {isLogin ? "Don't have an account?" : "Already have an account?"}
              <button
                onClick={() => setIsLogin(!isLogin)}
                className="ml-2 text-blue-500 hover:text-blue-700 font-medium"
              >
                {isLogin ? 'Sign up' : 'Sign in'}
              </button>
            </p>
          </div>
        </div>
      </div>
    </div>
  );
};

export default AuthPage;