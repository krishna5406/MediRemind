import React, { useState, useEffect } from 'react';
import { useAuth } from '../../context/AuthContext';
import { getMedicines } from '../../services/medicineService';
import { Medicine } from '../../types';
import { History, Check, X, Calendar, Filter } from 'lucide-react';

const MedicineHistory: React.FC = () => {
  const { currentUser } = useAuth();
  const [medicines, setMedicines] = useState<Medicine[]>([]);
  const [loading, setLoading] = useState(true);
  const [startDate, setStartDate] = useState(() => {
    const date = new Date();
    date.setDate(date.getDate() - 7); // Default to last 7 days
    return date.toISOString().split('T')[0];
  });
  const [endDate, setEndDate] = useState(() => {
    return new Date().toISOString().split('T')[0];
  });
  const [selectedMedicine, setSelectedMedicine] = useState<string>('all');

  useEffect(() => {
    const fetchMedicines = async () => {
      if (!currentUser) return;
      
      try {
        const userMedicines = await getMedicines(currentUser.id);
        setMedicines(userMedicines);
      } catch (error) {
        console.error('Failed to fetch medicines:', error);
      } finally {
        setLoading(false);
      }
    };
    
    fetchMedicines();
  }, [currentUser]);

  // Get all schedules within date range
  const getSchedulesInRange = () => {
    if (!medicines.length) return [];
    
    const start = new Date(startDate);
    const end = new Date(endDate);
    end.setHours(23, 59, 59); // Include the entire end day
    
    const filteredMedicines = selectedMedicine === 'all'
      ? medicines
      : medicines.filter(m => m.id === selectedMedicine);
    
    const records: Array<{
      date: Date;
      medicineName: string;
      medicineType: string;
      medicineId: string;
      scheduleId: string;
      time: string;
      taken: boolean;
      takenAt?: string;
    }> = [];
    
    filteredMedicines.forEach(medicine => {
      const medStartDate = new Date(medicine.startDate);
      const medEndDate = medicine.endDate ? new Date(medicine.endDate) : new Date(2099, 11, 31);
      
      // Skip if medicine date range doesn't overlap with selected range
      if (medEndDate < start || medStartDate > end) {
        return;
      }
      
      // For each day in range
      const currentDate = new Date(Math.max(start.getTime(), medStartDate.getTime()));
      while (currentDate <= end && currentDate <= medEndDate) {
        medicine.schedules.forEach(schedule => {
          records.push({
            date: new Date(currentDate),
            medicineName: medicine.name,
            medicineType: medicine.type,
            medicineId: medicine.id,
            scheduleId: schedule.id,
            time: schedule.time,
            taken: schedule.taken || false,
            takenAt: schedule.takenAt
          });
        });
        
        currentDate.setDate(currentDate.getDate() + 1);
      }
    });
    
    // Sort by date and time
    records.sort((a, b) => {
      const dateComparison = b.date.getTime() - a.date.getTime();
      if (dateComparison !== 0) return dateComparison;
      return a.time.localeCompare(b.time);
    });
    
    return records;
  };

  const schedules = getSchedulesInRange();

  // Group schedules by date
  const groupedSchedules: Record<string, typeof schedules> = {};
  schedules.forEach(schedule => {
    const dateStr = schedule.date.toISOString().split('T')[0];
    if (!groupedSchedules[dateStr]) {
      groupedSchedules[dateStr] = [];
    }
    groupedSchedules[dateStr].push(schedule);
  });

  // Format date for display
  const formatDate = (dateStr: string) => {
    return new Date(dateStr).toLocaleDateString('en-US', {
      weekday: 'long',
      year: 'numeric',
      month: 'long',
      day: 'numeric'
    });
  };

  // Format time for display
  const formatTime = (timeStr: string) => {
    const [hours, minutes] = timeStr.split(':').map(Number);
    return new Date(0, 0, 0, hours, minutes).toLocaleTimeString([], {
      hour: 'numeric',
      minute: '2-digit',
      hour12: true
    });
  };

  if (loading) {
    return (
      <div className="container mx-auto px-4 py-8 max-w-6xl flex justify-center">
        <div className="h-8 w-8 border-4 border-t-blue-500 border-blue-200 rounded-full animate-spin"></div>
      </div>
    );
  }

  return (
    <div className="container mx-auto px-4 py-8 max-w-6xl">
      <div className="flex items-center mb-6">
        <div className="p-3 bg-purple-50 rounded-full mr-4">
          <History className="h-6 w-6 text-purple-600" />
        </div>
        <h1 className="text-2xl font-bold text-gray-800">Medication History</h1>
      </div>
      
      <div className="bg-white rounded-lg shadow-md p-6 mb-8">
        <h2 className="text-lg font-medium text-gray-800 mb-4">Filter History</h2>
        
        <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
          <div>
            <label htmlFor="startDate" className="block text-sm font-medium text-gray-700 mb-1">
              Start Date
            </label>
            <input
              id="startDate"
              type="date"
              value={startDate}
              onChange={(e) => setStartDate(e.target.value)}
              max={endDate}
              className="w-full px-4 py-2 border border-gray-300 rounded-md focus:ring-purple-500 focus:border-purple-500"
            />
          </div>
          
          <div>
            <label htmlFor="endDate" className="block text-sm font-medium text-gray-700 mb-1">
              End Date
            </label>
            <input
              id="endDate"
              type="date"
              value={endDate}
              onChange={(e) => setEndDate(e.target.value)}
              min={startDate}
              max={new Date().toISOString().split('T')[0]}
              className="w-full px-4 py-2 border border-gray-300 rounded-md focus:ring-purple-500 focus:border-purple-500"
            />
          </div>
          
          <div>
            <label htmlFor="medicine" className="block text-sm font-medium text-gray-700 mb-1">
              Medicine
            </label>
            <select
              id="medicine"
              value={selectedMedicine}
              onChange={(e) => setSelectedMedicine(e.target.value)}
              className="w-full px-4 py-2 border border-gray-300 rounded-md focus:ring-purple-500 focus:border-purple-500"
            >
              <option value="all">All Medicines</option>
              {medicines.map((medicine) => (
                <option key={medicine.id} value={medicine.id}>
                  {medicine.name}
                </option>
              ))}
            </select>
          </div>
        </div>
      </div>
      
      <div className="bg-white rounded-lg shadow-md">
        {Object.keys(groupedSchedules).length === 0 ? (
          <div className="p-8 text-center text-gray-500">
            <Calendar className="h-12 w-12 mx-auto mb-4 text-gray-300" />
            <p>No medication history found for the selected date range.</p>
            <p className="text-sm mt-2">Try adjusting your filter criteria.</p>
          </div>
        ) : (
          <div className="divide-y divide-gray-100">
            {Object.entries(groupedSchedules).map(([dateStr, dateSchedules]) => (
              <div key={dateStr} className="p-6">
                <h3 className="font-medium text-lg text-gray-800 mb-4">
                  {formatDate(dateStr)}
                </h3>
                
                <div className="space-y-3">
                  {dateSchedules.map((schedule) => (
                    <div
                      key={`${schedule.medicineId}-${schedule.scheduleId}-${dateStr}`}
                      className="flex items-center p-3 rounded-md border border-gray-100 hover:bg-gray-50"
                    >
                      <div className="mr-4 min-w-[80px]">
                        {formatTime(schedule.time)}
                      </div>
                      
                      <div className="flex-1">
                        <p className="font-medium text-gray-800">{schedule.medicineName}</p>
                        <p className="text-sm text-gray-600 capitalize">{schedule.medicineType}</p>
                      </div>
                      
                      <div className={`flex items-center ${
                        schedule.taken ? 'text-green-600' : 'text-red-600'
                      }`}>
                        {schedule.taken ? (
                          <>
                            <Check className="h-5 w-5 mr-2" />
                            <span>Taken</span>
                          </>
                        ) : (
                          <>
                            <X className="h-5 w-5 mr-2" />
                            <span>Missed</span>
                          </>
                        )}
                      </div>
                    </div>
                  ))}
                </div>
              </div>
            ))}
          </div>
        )}
      </div>
    </div>
  );
};

export default MedicineHistory;