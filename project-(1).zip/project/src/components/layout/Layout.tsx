import React, { useState } from 'react';
import { Outlet, Link, useLocation } from 'react-router-dom';
import { useAuth } from '../../context/AuthContext';
import { 
  Bell, 
  LayoutDashboard, 
  Pill,
  History,
  Calendar,
  Settings,
  Menu,
  X,
  LogOut,
  User
} from 'lucide-react';

const Layout: React.FC = () => {
  const { currentUser, logout } = useAuth();
  const [mobileMenuOpen, setMobileMenuOpen] = useState(false);
  const location = useLocation();
  
  const isActive = (path: string) => {
    return location.pathname === path;
  };
  
  const handleLogout = async () => {
    try {
      await logout();
      window.location.href = '/';
    } catch (error) {
      console.error('Failed to log out', error);
    }
  };
  
  if (!currentUser) {
    return <Outlet />;
  }
  
  return (
    <div className="min-h-screen bg-gray-50 flex flex-col">
      {/* Mobile Header */}
      <header className="bg-white shadow-sm p-4 md:hidden flex items-center justify-between">
        <Link to="/dashboard" className="flex items-center">
          <Bell className="h-6 w-6 text-blue-500 mr-2" />
          <span className="font-bold text-xl">MediTrack</span>
        </Link>
        
        <button 
          onClick={() => setMobileMenuOpen(!mobileMenuOpen)}
          className="text-gray-500 focus:outline-none"
        >
          {mobileMenuOpen ? (
            <X className="h-6 w-6" />
          ) : (
            <Menu className="h-6 w-6" />
          )}
        </button>
      </header>
      
      <div className="flex flex-1">
        {/* Sidebar for desktop */}
        <aside className="hidden md:flex md:w-64 lg:w-72 bg-white border-r border-gray-200 flex-col">
          <div className="p-6 border-b border-gray-200">
            <Link to="/dashboard" className="flex items-center">
              <Bell className="h-6 w-6 text-blue-500 mr-2" />
              <span className="font-bold text-xl">MediTrack</span>
            </Link>
          </div>
          
          <nav className="flex-1 p-4">
            <ul className="space-y-2">
              <li>
                <Link 
                  to="/dashboard" 
                  className={`flex items-center px-4 py-3 rounded-md ${
                    isActive('/dashboard') 
                      ? 'bg-blue-50 text-blue-600' 
                      : 'text-gray-700 hover:bg-gray-50'
                  }`}
                >
                  <LayoutDashboard className="h-5 w-5 mr-3" />
                  Dashboard
                </Link>
              </li>
              
              <li>
                <Link 
                  to="/medicines/add" 
                  className={`flex items-center px-4 py-3 rounded-md ${
                    isActive('/medicines/add') 
                      ? 'bg-blue-50 text-blue-600' 
                      : 'text-gray-700 hover:bg-gray-50'
                  }`}
                >
                  <Pill className="h-5 w-5 mr-3" />
                  Add Medicine
                </Link>
              </li>
              
              <li>
                <Link 
                  to="/history" 
                  className={`flex items-center px-4 py-3 rounded-md ${
                    isActive('/history') 
                      ? 'bg-blue-50 text-blue-600' 
                      : 'text-gray-700 hover:bg-gray-50'
                  }`}
                >
                  <History className="h-5 w-5 mr-3" />
                  History
                </Link>
              </li>
              
              <li>
                <Link 
                  to="/calendar" 
                  className={`flex items-center px-4 py-3 rounded-md ${
                    isActive('/calendar') 
                      ? 'bg-blue-50 text-blue-600' 
                      : 'text-gray-700 hover:bg-gray-50'
                  }`}
                >
                  <Calendar className="h-5 w-5 mr-3" />
                  Calendar
                </Link>
              </li>
              
              <li>
                <Link 
                  to="/settings" 
                  className={`flex items-center px-4 py-3 rounded-md ${
                    isActive('/settings') 
                      ? 'bg-blue-50 text-blue-600' 
                      : 'text-gray-700 hover:bg-gray-50'
                  }`}
                >
                  <Settings className="h-5 w-5 mr-3" />
                  Settings
                </Link>
              </li>
            </ul>
          </nav>
          
          <div className="p-4 border-t border-gray-200">
            <div className="flex items-center mb-4">
              <div className="w-10 h-10 rounded-full bg-blue-100 flex items-center justify-center">
                <User className="h-5 w-5 text-blue-600" />
              </div>
              <div className="ml-3">
                <p className="font-medium text-gray-800">{currentUser.email}</p>
              </div>
            </div>
            
            <button
              onClick={handleLogout}
              className="flex items-center px-4 py-2 w-full text-gray-700 hover:bg-gray-50 rounded-md"
            >
              <LogOut className="h-5 w-5 mr-3" />
              Logout
            </button>
          </div>
        </aside>
        
        {/* Mobile menu slide-over */}
        {mobileMenuOpen && (
          <div className="md:hidden fixed inset-0 z-40 flex">
            <div className="fixed inset-0 bg-gray-600 bg-opacity-75" onClick={() => setMobileMenuOpen(false)}></div>
            
            <div className="relative flex-1 flex flex-col max-w-xs w-full bg-white">
              <div className="p-4 border-b border-gray-200 flex items-center justify-between">
                <Link to="/dashboard" className="flex items-center">
                  <Bell className="h-6 w-6 text-blue-500 mr-2" />
                  <span className="font-bold text-xl">MediTrack</span>
                </Link>
                
                <button 
                  onClick={() => setMobileMenuOpen(false)}
                  className="text-gray-500 focus:outline-none"
                >
                  <X className="h-6 w-6" />
                </button>
              </div>
              
              <nav className="flex-1 p-4">
                <ul className="space-y-2">
                  <li>
                    <Link 
                      to="/dashboard" 
                      className={`flex items-center px-4 py-3 rounded-md ${
                        isActive('/dashboard') 
                          ? 'bg-blue-50 text-blue-600' 
                          : 'text-gray-700 hover:bg-gray-50'
                      }`}
                      onClick={() => setMobileMenuOpen(false)}
                    >
                      <LayoutDashboard className="h-5 w-5 mr-3" />
                      Dashboard
                    </Link>
                  </li>
                  
                  <li>
                    <Link 
                      to="/medicines/add" 
                      className={`flex items-center px-4 py-3 rounded-md ${
                        isActive('/medicines/add') 
                          ? 'bg-blue-50 text-blue-600' 
                          : 'text-gray-700 hover:bg-gray-50'
                      }`}
                      onClick={() => setMobileMenuOpen(false)}
                    >
                      <Pill className="h-5 w-5 mr-3" />
                      Add Medicine
                    </Link>
                  </li>
                  
                  <li>
                    <Link 
                      to="/history" 
                      className={`flex items-center px-4 py-3 rounded-md ${
                        isActive('/history') 
                          ? 'bg-blue-50 text-blue-600' 
                          : 'text-gray-700 hover:bg-gray-50'
                      }`}
                      onClick={() => setMobileMenuOpen(false)}
                    >
                      <History className="h-5 w-5 mr-3" />
                      History
                    </Link>
                  </li>
                  
                  <li>
                    <Link 
                      to="/calendar" 
                      className={`flex items-center px-4 py-3 rounded-md ${
                        isActive('/calendar') 
                          ? 'bg-blue-50 text-blue-600' 
                          : 'text-gray-700 hover:bg-gray-50'
                      }`}
                      onClick={() => setMobileMenuOpen(false)}
                    >
                      <Calendar className="h-5 w-5 mr-3" />
                      Calendar
                    </Link>
                  </li>
                  
                  <li>
                    <Link 
                      to="/settings" 
                      className={`flex items-center px-4 py-3 rounded-md ${
                        isActive('/settings') 
                          ? 'bg-blue-50 text-blue-600' 
                          : 'text-gray-700 hover:bg-gray-50'
                      }`}
                      onClick={() => setMobileMenuOpen(false)}
                    >
                      <Settings className="h-5 w-5 mr-3" />
                      Settings
                    </Link>
                  </li>
                </ul>
              </nav>
              
              <div className="p-4 border-t border-gray-200">
                <div className="flex items-center mb-4">
                  <div className="w-10 h-10 rounded-full bg-blue-100 flex items-center justify-center">
                    <User className="h-5 w-5 text-blue-600" />
                  </div>
                  <div className="ml-3">
                    <p className="font-medium text-gray-800">{currentUser.email}</p>
                  </div>
                </div>
                
                <button
                  onClick={handleLogout}
                  className="flex items-center px-4 py-2 w-full text-gray-700 hover:bg-gray-50 rounded-md"
                >
                  <LogOut className="h-5 w-5 mr-3" />
                  Logout
                </button>
              </div>
            </div>
          </div>
        )}
        
        {/* Main content */}
        <main className="flex-1 overflow-auto">
          <Outlet />
        </main>
      </div>
    </div>
  );
};

export default Layout;