import React, { useState, useEffect } from 'react';
import { useAuth } from '../../context/AuthContext';
import { Medicine, MedicineType } from '../../types';
import { createMedicine, updateMedicine } from '../../services/medicineService';
import { Plus, Minus, X } from 'lucide-react';

interface MedicineFormProps {
  medicine?: Medicine;
  onSave?: () => void;
}

const MEDICINE_TYPES: MedicineType[] = [
  'capsule',
  'tablet',
  'liquid',
  'injection',
  'drops',
  'inhaler',
  'topical',
  'patch',
  'other'
];

const COLOR_OPTIONS = [
  '#4A90E2', // Blue
  '#50C878', // Green
  '#F5A623', // Orange
  '#C13584', // Purple
  '#E74C3C', // Red
  '#34495E'  // Dark Blue
];

const MedicineForm: React.FC<MedicineFormProps> = ({ medicine, onSave }) => {
  const { currentUser } = useAuth();
  const [name, setName] = useState(medicine?.name || '');
  const [type, setType] = useState<MedicineType>(medicine?.type || 'tablet');
  const [dosage, setDosage] = useState(medicine?.dosage || '');
  const [instructions, setInstructions] = useState(medicine?.instructions || '');
  const [startDate, setStartDate] = useState(medicine?.startDate || new Date().toISOString().split('T')[0]);
  const [endDate, setEndDate] = useState(medicine?.endDate || '');
  const [color, setColor] = useState(medicine?.color || COLOR_OPTIONS[0]);
  const [schedules, setSchedules] = useState<{ time: string; id?: string }[]>(
    medicine?.schedules.length
      ? medicine.schedules.map(s => ({ time: s.time, id: s.id }))
      : [{ time: '09:00' }]
  );
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState<string | null>(null);

  const validateForm = (): boolean => {
    if (!name.trim()) {
      setError('Medicine name is required');
      return false;
    }
    
    if (!dosage.trim()) {
      setError('Dosage is required');
      return false;
    }
    
    if (!startDate) {
      setError('Start date is required');
      return false;
    }
    
    if (schedules.length === 0) {
      setError('At least one schedule time is required');
      return false;
    }
    
    if (endDate && new Date(endDate) < new Date(startDate)) {
      setError('End date cannot be before start date');
      return false;
    }
    
    setError(null);
    return true;
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    
    if (!currentUser) {
      setError('You must be logged in to save medicines');
      return;
    }
    
    if (!validateForm()) {
      return;
    }
    
    try {
      setLoading(true);
      
      if (medicine) {
        // Update existing medicine
        await updateMedicine(medicine.id, {
          name,
          type,
          dosage,
          instructions,
          startDate,
          endDate: endDate || undefined,
          schedules,
          color
        });
      } else {
        // Create new medicine
        await createMedicine(
          currentUser.id,
          name,
          type,
          dosage,
          startDate,
          endDate || undefined,
          schedules,
          instructions,
          color
        );
      }
      
      if (onSave) {
        onSave();
      }
    } catch (error) {
      console.error('Failed to save medicine:', error);
      setError(error instanceof Error ? error.message : 'Failed to save medicine');
    } finally {
      setLoading(false);
    }
  };

  const addSchedule = () => {
    setSchedules([...schedules, { time: '09:00' }]);
  };

  const removeSchedule = (index: number) => {
    const newSchedules = [...schedules];
    newSchedules.splice(index, 1);
    setSchedules(newSchedules);
  };

  const updateScheduleTime = (index: number, time: string) => {
    const newSchedules = [...schedules];
    newSchedules[index] = { ...newSchedules[index], time };
    setSchedules(newSchedules);
  };

  return (
    <div className="bg-white rounded-lg shadow-md p-6">
      <form onSubmit={handleSubmit} className="space-y-6">
        {error && (
          <div className="p-3 bg-red-50 border border-red-200 text-red-600 rounded-md text-sm">
            {error}
          </div>
        )}
        
        <div>
          <label htmlFor="name" className="block text-sm font-medium text-gray-700 mb-1">
            Medicine Name
          </label>
          <input
            id="name"
            type="text"
            value={name}
            onChange={(e) => setName(e.target.value)}
            className="w-full px-4 py-2 border border-gray-300 rounded-md focus:ring-blue-500 focus:border-blue-500"
            placeholder="E.g., Ibuprofen"
            required
          />
        </div>
        
        <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
          <div>
            <label htmlFor="type" className="block text-sm font-medium text-gray-700 mb-1">
              Medicine Type
            </label>
            <select
              id="type"
              value={type}
              onChange={(e) => setType(e.target.value as MedicineType)}
              className="w-full px-4 py-2 border border-gray-300 rounded-md focus:ring-blue-500 focus:border-blue-500"
            >
              {MEDICINE_TYPES.map((type) => (
                <option key={type} value={type}>
                  {type.charAt(0).toUpperCase() + type.slice(1)}
                </option>
              ))}
            </select>
          </div>
          
          <div>
            <label htmlFor="dosage" className="block text-sm font-medium text-gray-700 mb-1">
              Dosage
            </label>
            <input
              id="dosage"
              type="text"
              value={dosage}
              onChange={(e) => setDosage(e.target.value)}
              className="w-full px-4 py-2 border border-gray-300 rounded-md focus:ring-blue-500 focus:border-blue-500"
              placeholder="E.g., 200mg"
              required
            />
          </div>
        </div>
        
        <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
          <div>
            <label htmlFor="startDate" className="block text-sm font-medium text-gray-700 mb-1">
              Start Date
            </label>
            <input
              id="startDate"
              type="date"
              value={startDate}
              onChange={(e) => setStartDate(e.target.value)}
              className="w-full px-4 py-2 border border-gray-300 rounded-md focus:ring-blue-500 focus:border-blue-500"
              required
            />
          </div>
          
          <div>
            <label htmlFor="endDate" className="block text-sm font-medium text-gray-700 mb-1">
              End Date (Optional)
            </label>
            <input
              id="endDate"
              type="date"
              value={endDate}
              onChange={(e) => setEndDate(e.target.value)}
              className="w-full px-4 py-2 border border-gray-300 rounded-md focus:ring-blue-500 focus:border-blue-500"
            />
          </div>
        </div>
        
        <div>
          <label className="block text-sm font-medium text-gray-700 mb-1">
            Color Label (Optional)
          </label>
          <div className="flex space-x-2">
            {COLOR_OPTIONS.map((colorOption) => (
              <button
                key={colorOption}
                type="button"
                className={`w-8 h-8 rounded-full ${
                  color === colorOption ? 'ring-2 ring-offset-2 ring-blue-500' : ''
                }`}
                style={{ backgroundColor: colorOption }}
                onClick={() => setColor(colorOption)}
              />
            ))}
          </div>
        </div>
        
        <div>
          <label className="block text-sm font-medium text-gray-700 mb-1">
            Reminder Times
          </label>
          
          <div className="space-y-3">
            {schedules.map((schedule, index) => (
              <div key={index} className="flex items-center">
                <input
                  type="time"
                  value={schedule.time}
                  onChange={(e) => updateScheduleTime(index, e.target.value)}
                  className="px-4 py-2 border border-gray-300 rounded-md focus:ring-blue-500 focus:border-blue-500"
                  required
                />
                
                <button
                  type="button"
                  onClick={() => removeSchedule(index)}
                  className="ml-2 p-2 text-red-600 hover:bg-red-50 rounded-full disabled:opacity-50"
                  disabled={schedules.length <= 1}
                >
                  <Minus className="h-4 w-4" />
                </button>
              </div>
            ))}
            
            <button
              type="button"
              onClick={addSchedule}
              className="flex items-center text-blue-600 hover:text-blue-800 text-sm"
            >
              <Plus className="h-4 w-4 mr-1" />
              Add Another Time
            </button>
          </div>
        </div>
        
        <div>
          <label htmlFor="instructions" className="block text-sm font-medium text-gray-700 mb-1">
            Special Instructions (Optional)
          </label>
          <textarea
            id="instructions"
            value={instructions}
            onChange={(e) => setInstructions(e.target.value)}
            className="w-full px-4 py-2 border border-gray-300 rounded-md focus:ring-blue-500 focus:border-blue-500"
            placeholder="E.g., Take with food"
            rows={3}
          />
        </div>
        
        <div className="flex justify-end space-x-3">
          <a
            href="/dashboard"
            className="px-4 py-2 border border-gray-300 text-gray-700 rounded-md hover:bg-gray-50"
          >
            Cancel
          </a>
          <button
            type="submit"
            disabled={loading}
            className="px-4 py-2 bg-blue-500 text-white rounded-md hover:bg-blue-600 focus:outline-none focus:ring-2 focus:ring-blue-500 focus:ring-offset-2 transition-colors"
          >
            {loading ? (
              <div className="h-5 w-5 border-2 border-t-transparent border-white rounded-full animate-spin"></div>
            ) : (
              medicine ? 'Update Medicine' : 'Add Medicine'
            )}
          </button>
        </div>
      </form>
    </div>
  );
};

export default MedicineForm;