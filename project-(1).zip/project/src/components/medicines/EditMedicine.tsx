import React, { useState, useEffect } from 'react';
import { useParams, useNavigate } from 'react-router-dom';
import MedicineForm from './MedicineForm';
import { getMedicineById } from '../../services/medicineService';
import { Medicine } from '../../types';
import { ArrowLeft, Pill } from 'lucide-react';

const EditMedicine: React.FC = () => {
  const { id } = useParams<{ id: string }>();
  const navigate = useNavigate();
  const [medicine, setMedicine] = useState<Medicine | null>(null);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);

  useEffect(() => {
    const loadMedicine = async () => {
      if (!id) {
        setError('Medicine ID is missing');
        setLoading(false);
        return;
      }
      
      try {
        const medicineData = await getMedicineById(id);
        
        if (!medicineData) {
          setError('Medicine not found');
          setLoading(false);
          return;
        }
        
        setMedicine(medicineData);
      } catch (err) {
        setError('Failed to load medicine details');
        console.error(err);
      } finally {
        setLoading(false);
      }
    };
    
    loadMedicine();
  }, [id]);

  const handleSave = () => {
    navigate('/dashboard');
  };

  if (loading) {
    return (
      <div className="container mx-auto px-4 py-8 max-w-3xl flex justify-center items-center min-h-[300px]">
        <div className="h-8 w-8 border-4 border-t-blue-500 border-blue-200 rounded-full animate-spin"></div>
      </div>
    );
  }

  if (error || !medicine) {
    return (
      <div className="container mx-auto px-4 py-8 max-w-3xl">
        <div className="bg-red-50 text-red-600 p-4 rounded-md">
          <p className="font-medium">Error</p>
          <p>{error || 'Unable to load medicine'}</p>
          <a
            href="/dashboard"
            className="mt-4 inline-block px-4 py-2 bg-white border border-red-200 rounded-md text-red-600 hover:bg-red-50"
          >
            Return to Dashboard
          </a>
        </div>
      </div>
    );
  }

  return (
    <div className="container mx-auto px-4 py-8 max-w-3xl">
      <div className="mb-6">
        <a
          href="/dashboard"
          className="inline-flex items-center text-blue-600 hover:text-blue-800"
        >
          <ArrowLeft className="h-4 w-4 mr-1" />
          Back to Dashboard
        </a>
      </div>
      
      <div className="flex items-center mb-6">
        <div className="p-3 bg-blue-50 rounded-full mr-4">
          <Pill className="h-6 w-6 text-blue-500" />
        </div>
        <h1 className="text-2xl font-bold text-gray-800">Edit Medicine</h1>
      </div>
      
      <MedicineForm medicine={medicine} onSave={handleSave} />
    </div>
  );
};

export default EditMedicine;