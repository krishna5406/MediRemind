import React from 'react';
import { useNavigate } from 'react-router-dom';
import MedicineForm from './MedicineForm';
import { ArrowLeft, Pill } from 'lucide-react';

const AddMedicine: React.FC = () => {
  const navigate = useNavigate();

  const handleSave = () => {
    navigate('/dashboard');
  };

  return (
    <div className="container mx-auto px-4 py-8 max-w-3xl">
      <div className="mb-6">
        <a
          href="/dashboard"
          className="inline-flex items-center text-blue-600 hover:text-blue-800"
        >
          <ArrowLeft className="h-4 w-4 mr-1" />
          Back to Dashboard
        </a>
      </div>
      
      <div className="flex items-center mb-6">
        <div className="p-3 bg-blue-50 rounded-full mr-4">
          <Pill className="h-6 w-6 text-blue-500" />
        </div>
        <h1 className="text-2xl font-bold text-gray-800">Add New Medicine</h1>
      </div>
      
      <MedicineForm onSave={handleSave} />
    </div>
  );
};

export default AddMedicine;