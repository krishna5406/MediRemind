import React from 'react';
import { Medicine } from '../../types';
import { Pill, Cable as Capsule, Wine as Vaccine, Droplet, SprayCan as Spray, Edit, Trash, Clock } from 'lucide-react';
import { deleteMedicine } from '../../services/medicineService';

interface MedicineListProps {
  medicines: Medicine[];
  onUpdate?: () => void;
}

const MedicineList: React.FC<MedicineListProps> = ({ medicines, onUpdate }) => {
  const getMedicineIcon = (type: string, className: string = 'h-5 w-5') => {
    switch (type) {
      case 'capsule':
        return <Capsule className={className} />;
      case 'tablet':
        return <Pill className={className} />;
      case 'injection':
        return <Vaccine className={className} />;
      case 'liquid':
        return <Droplet className={className} />;
      case 'drops':
        return <Droplet className={className} />;
      case 'inhaler':
        return <Spray className={className} />;
      default:
        return <Pill className={className} />;
    }
  };

  const handleDelete = async (id: string) => {
    if (window.confirm('Are you sure you want to delete this medicine?')) {
      try {
        await deleteMedicine(id);
        if (onUpdate) {
          onUpdate();
        }
      } catch (error) {
        console.error('Failed to delete medicine:', error);
      }
    }
  };

  if (medicines.length === 0) {
    return (
      <div className="py-10 text-center text-gray-500">
        <Pill className="h-12 w-12 mx-auto mb-4 text-gray-300" />
        <p>No medications added yet.</p>
        <p className="text-sm mt-2">Add your first medication to get started.</p>
      </div>
    );
  }

  return (
    <div className="grid gap-4 grid-cols-1 md:grid-cols-2">
      {medicines.map((medicine) => (
        <div 
          key={medicine.id}
          className="border border-gray-200 rounded-lg p-4 hover:shadow-md transition-shadow relative overflow-hidden"
        >
          {medicine.color && (
            <div 
              className="absolute top-0 left-0 w-2 h-full" 
              style={{ backgroundColor: medicine.color }}
            ></div>
          )}
          
          <div className="flex items-start pl-3">
            <div className="p-2 bg-blue-50 rounded-full mr-4">
              {getMedicineIcon(medicine.type)}
            </div>
            
            <div className="flex-1">
              <h3 className="font-medium text-lg text-gray-800">{medicine.name}</h3>
              <p className="text-sm text-gray-600 capitalize">
                {medicine.type} - {medicine.dosage}
              </p>
              
              <div className="mt-3 flex items-center">
                <Clock className="h-4 w-4 text-gray-400 mr-1" />
                <span className="text-xs text-gray-500">
                  {medicine.schedules.length} {medicine.schedules.length === 1 ? 'reminder' : 'reminders'} daily
                </span>
              </div>
              
              <div className="mt-3 text-xs text-gray-500">
                {medicine.startDate && `From: ${new Date(medicine.startDate).toLocaleDateString()}`}
                {medicine.endDate && ` To: ${new Date(medicine.endDate).toLocaleDateString()}`}
              </div>
            </div>
            
            <div className="flex space-x-1">
              <a
                href={`/medicines/edit/${medicine.id}`}
                className="p-2 text-blue-600 hover:bg-blue-50 rounded-full"
                title="Edit"
              >
                <Edit className="h-4 w-4" />
              </a>
              
              <button
                onClick={() => handleDelete(medicine.id)}
                className="p-2 text-red-600 hover:bg-red-50 rounded-full"
                title="Delete"
              >
                <Trash className="h-4 w-4" />
              </button>
            </div>
          </div>
        </div>
      ))}
    </div>
  );
};

export default MedicineList;