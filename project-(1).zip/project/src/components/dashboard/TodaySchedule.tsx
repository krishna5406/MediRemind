import React, { useState, useEffect } from 'react';
import { Medicine } from '../../types';
import { recordDosageTaken } from '../../services/medicineService';
import { Check, Clock } from 'lucide-react';

interface TodayScheduleProps {
  medicines: Medicine[];
}

interface ScheduledDose {
  medicineId: string;
  medicineName: string;
  scheduleId: string;
  time: string;
  type: string;
  dosage: string;
  taken: boolean;
  color?: string;
}

const TodaySchedule: React.FC<TodayScheduleProps> = ({ medicines }) => {
  const [scheduledDoses, setScheduledDoses] = useState<ScheduledDose[]>([]);
  const [currentTime, setCurrentTime] = useState(new Date());

  // Update current time every minute
  useEffect(() => {
    const intervalId = setInterval(() => {
      setCurrentTime(new Date());
    }, 60000);
    
    return () => clearInterval(intervalId);
  }, []);

  // Get today's schedule from medicines
  useEffect(() => {
    const today = new Date();
    const todayString = today.toISOString().split('T')[0];
    
    const doses: ScheduledDose[] = [];
    
    medicines.forEach(medicine => {
      // Check if medicine is active for today
      const startDate = new Date(medicine.startDate);
      const endDate = medicine.endDate ? new Date(medicine.endDate) : null;
      
      if (startDate > today || (endDate && endDate < today)) {
        return;
      }
      
      medicine.schedules.forEach(schedule => {
        doses.push({
          medicineId: medicine.id,
          medicineName: medicine.name,
          scheduleId: schedule.id,
          time: schedule.time,
          type: medicine.type,
          dosage: medicine.dosage,
          taken: schedule.taken || false,
          color: medicine.color,
        });
      });
    });
    
    // Sort by time
    doses.sort((a, b) => {
      return a.time.localeCompare(b.time);
    });
    
    setScheduledDoses(doses);
  }, [medicines]);

  const handleMarkAsTaken = async (medicineId: string, scheduleId: string) => {
    try {
      await recordDosageTaken(medicineId, scheduleId);
      
      // Update the local state
      setScheduledDoses(doses =>
        doses.map(dose =>
          dose.medicineId === medicineId && dose.scheduleId === scheduleId
            ? { ...dose, taken: true }
            : dose
        )
      );
    } catch (error) {
      console.error('Failed to mark medication as taken:', error);
    }
  };

  // Format time string to display
  const formatTime = (timeString: string) => {
    const [hours, minutes] = timeString.split(':').map(Number);
    return new Date(0, 0, 0, hours, minutes).toLocaleTimeString([], { 
      hour: 'numeric', 
      minute: '2-digit',
      hour12: true 
    });
  };

  // Determine if a scheduled dose is upcoming, current, or past
  const getDoseStatus = (timeString: string) => {
    const [hours, minutes] = timeString.split(':').map(Number);
    const doseTime = new Date();
    doseTime.setHours(hours, minutes, 0, 0);
    
    const now = currentTime;
    const diffMs = doseTime.getTime() - now.getTime();
    const diffMinutes = diffMs / (1000 * 60);
    
    if (diffMinutes < -30) return 'past';
    if (diffMinutes < 30) return 'current';
    return 'upcoming';
  };

  if (scheduledDoses.length === 0) {
    return (
      <div className="py-10 text-center text-gray-500">
        <Clock className="h-12 w-12 mx-auto mb-4 text-gray-300" />
        <p>No medications scheduled for today.</p>
        <p className="text-sm mt-2">Add medications to see your schedule.</p>
      </div>
    );
  }

  return (
    <div className="space-y-4">
      {scheduledDoses.map((dose) => {
        const status = getDoseStatus(dose.time);
        
        let bgColor = 'bg-white';
        let borderColor = 'border-gray-100';
        
        if (dose.taken) {
          bgColor = 'bg-green-50';
          borderColor = 'border-green-100';
        } else if (status === 'current') {
          bgColor = 'bg-blue-50';
          borderColor = 'border-blue-100';
        } else if (status === 'past') {
          bgColor = 'bg-red-50';
          borderColor = 'border-red-100';
        }
        
        return (
          <div 
            key={`${dose.medicineId}-${dose.scheduleId}`}
            className={`p-4 border-l-4 ${borderColor} ${bgColor} rounded-md flex items-center justify-between transition-all duration-300`}
          >
            <div className="flex items-center">
              <div className="mr-4 flex-shrink-0">
                <div className="text-2xl font-semibold">{formatTime(dose.time)}</div>
                <div className="text-xs text-gray-500">
                  {status === 'current' ? 'Now' : status === 'past' ? 'Missed' : 'Upcoming'}
                </div>
              </div>
              
              <div>
                <h3 className="font-medium text-gray-800">{dose.medicineName}</h3>
                <p className="text-sm text-gray-600 capitalize">{dose.type} - {dose.dosage}</p>
              </div>
            </div>
            
            {!dose.taken ? (
              <button
                onClick={() => handleMarkAsTaken(dose.medicineId, dose.scheduleId)}
                className="px-3 py-2 bg-white text-green-600 border border-green-200 rounded-md hover:bg-green-50 flex items-center"
              >
                <Check className="h-4 w-4 mr-1" />
                <span>Mark as Taken</span>
              </button>
            ) : (
              <div className="px-3 py-2 text-green-600 flex items-center">
                <Check className="h-4 w-4 mr-1" />
                <span>Taken</span>
              </div>
            )}
          </div>
        );
      })}
    </div>
  );
};

export default TodaySchedule;