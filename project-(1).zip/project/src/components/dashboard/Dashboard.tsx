import React, { useState, useEffect } from 'react';
import { useAuth } from '../../context/AuthContext';
import { Medicine } from '../../types';
import { getMedicines } from '../../services/medicineService';
import { Bell, Plus, Calendar, Clock, History, Settings, Pill } from 'lucide-react';
import MedicineList from '../medicines/MedicineList';
import TodaySchedule from './TodaySchedule';
import { requestNotificationPermission, scheduleReminders } from '../../services/reminderService';

const Dashboard: React.FC = () => {
  const { currentUser } = useAuth();
  const [medicines, setMedicines] = useState<Medicine[]>([]);
  const [loading, setLoading] = useState(true);
  const [notificationsEnabled, setNotificationsEnabled] = useState(false);

  useEffect(() => {
    const checkNotificationPermission = async () => {
      if ('Notification' in window) {
        const permissionGranted = Notification.permission === 'granted';
        setNotificationsEnabled(permissionGranted);
      }
    };
    
    checkNotificationPermission();
  }, []);

  useEffect(() => {
    const loadMedicines = async () => {
      if (currentUser) {
        try {
          const userMedicines = await getMedicines(currentUser.id);
          setMedicines(userMedicines);
          
          // Schedule reminders for all active medicines
          scheduleReminders(userMedicines);
        } catch (error) {
          console.error('Failed to load medicines:', error);
        } finally {
          setLoading(false);
        }
      }
    };
    
    loadMedicines();
  }, [currentUser]);

  const handleEnableNotifications = async () => {
    const granted = await requestNotificationPermission();
    setNotificationsEnabled(granted);
    
    if (granted) {
      // Schedule reminders again after permission is granted
      scheduleReminders(medicines);
    }
  };

  if (!currentUser) {
    return <div>Please log in to view your dashboard.</div>;
  }

  return (
    <div className="container mx-auto px-4 py-8 max-w-6xl">
      <header className="flex flex-col md:flex-row md:items-center justify-between mb-8">
        <div>
          <h1 className="text-2xl font-bold text-gray-800">Your Medicine Dashboard</h1>
          <p className="text-gray-600">Track and manage your medications</p>
        </div>
        
        {!notificationsEnabled && (
          <button
            onClick={handleEnableNotifications}
            className="mt-4 md:mt-0 flex items-center px-4 py-2 bg-blue-500 text-white rounded-md hover:bg-blue-600 transition-colors"
          >
            <Bell className="h-4 w-4 mr-2" />
            Enable Notifications
          </button>
        )}
      </header>

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
        <div className="lg:col-span-2">
          <div className="bg-white rounded-lg shadow-md mb-8 p-6">
            <div className="flex items-center justify-between mb-6">
              <h2 className="text-xl font-semibold text-gray-800">Today's Schedule</h2>
              <span className="text-sm text-gray-500">
                {new Date().toLocaleDateString('en-US', { weekday: 'long', month: 'long', day: 'numeric' })}
              </span>
            </div>
            
            <TodaySchedule medicines={medicines} />
          </div>
          
          <div className="bg-white rounded-lg shadow-md p-6">
            <div className="flex items-center justify-between mb-6">
              <h2 className="text-xl font-semibold text-gray-800">Your Medicines</h2>
              <a
                href="/medicines/add"
                className="flex items-center text-sm px-3 py-2 bg-blue-50 text-blue-600 rounded-md hover:bg-blue-100 transition-colors"
              >
                <Plus className="h-4 w-4 mr-1" />
                Add Medicine
              </a>
            </div>
            
            {loading ? (
              <div className="py-8 flex justify-center">
                <div className="h-8 w-8 border-4 border-t-blue-500 border-blue-200 rounded-full animate-spin"></div>
              </div>
            ) : (
              <MedicineList medicines={medicines} />
            )}
          </div>
        </div>
        
        <div>
          <div className="bg-white rounded-lg shadow-md p-6 mb-8">
            <h2 className="text-xl font-semibold text-gray-800 mb-4">Quick Actions</h2>
            <div className="space-y-3">
              <a
                href="/medicines/add"
                className="flex items-center p-3 rounded-md hover:bg-gray-50 transition-colors"
              >
                <div className="p-2 bg-green-50 rounded-md mr-3">
                  <Plus className="h-5 w-5 text-green-600" />
                </div>
                <span>Add New Medicine</span>
              </a>
              
              <a
                href="/calendar"
                className="flex items-center p-3 rounded-md hover:bg-gray-50 transition-colors"
              >
                <div className="p-2 bg-blue-50 rounded-md mr-3">
                  <Calendar className="h-5 w-5 text-blue-600" />
                </div>
                <span>View Calendar</span>
              </a>
              
              <a
                href="/history"
                className="flex items-center p-3 rounded-md hover:bg-gray-50 transition-colors"
              >
                <div className="p-2 bg-purple-50 rounded-md mr-3">
                  <History className="h-5 w-5 text-purple-600" />
                </div>
                <span>Medication History</span>
              </a>
              
              <a
                href="/settings"
                className="flex items-center p-3 rounded-md hover:bg-gray-50 transition-colors"
              >
                <div className="p-2 bg-gray-50 rounded-md mr-3">
                  <Settings className="h-5 w-5 text-gray-600" />
                </div>
                <span>Settings</span>
              </a>
            </div>
          </div>
          
          <div className="bg-blue-50 rounded-lg p-6">
            <div className="flex items-start mb-4">
              <Pill className="h-6 w-6 text-blue-500 mr-3 mt-1" />
              <div>
                <h3 className="font-semibold text-blue-800 mb-1">Medicine Tip</h3>
                <p className="text-blue-700 text-sm">
                  Always take your medication at the same time each day to develop a routine and ensure consistency.
                </p>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};

export default Dashboard;